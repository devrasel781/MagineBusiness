<?php
/**
* Plugin Name: TMC Posts
* Plugin URI: https://www.thememasters.club/
* Description: Elementor Posts Addon
* Version: 1.4
* Author: ThemeMasters
* Author URI: https://www.thememasters.club/
* License: URI: https://www.thememasters.club/terms-conditions/
* Text Domain: tmc-posts
* Domain Path: /languages/
*/

/* ---------------------------------------------------------
ELEMENTOR
----------------------------------------------------------- */

include_once('elementor.php');

/* Create a new category */
if ( ! function_exists( 'tmc_elementor_widget_categories' ) ) {
function tmc_elementor_widget_categories( $elements_manager ) {

	$elements_manager->add_category(
		'tmc-widgets',
		[
			'title' => esc_html__( 'TMC Addons', 'tmc-posts' ),
			'icon' => 'fa fa-plug',
		]
	);

}
add_action( 'elementor/elements/categories_registered', 'tmc_elementor_widget_categories' );
}

/* ---------------------------------------------------------
CUSTOM EXCERPT LENGTH
----------------------------------------------------------- */

function tmc_posts_excerpt($charlength) {
	$excerpt = get_the_excerpt();
	$charlength++;

	if ( mb_strlen( $excerpt ) > $charlength ) {
		$subex = mb_substr( $excerpt, 0, $charlength );
		$exwords = explode( ' ', $subex );
		$excut = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
		if ( $excut < 0 ) {
			return mb_substr( $subex, 0, $excut ) . ' ...';
		} else {
			return $subex . ' ...';
		}
	} else {
		return $excerpt;
	}
}
?>