<?php
namespace Elementortmcposts;

class tmcpostsLoadElementor {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
    
    public function widget_scripts() {
        wp_register_script('egemenerd-grid', plugin_dir_url( __FILE__ ) . 'js/egemenerd-grid.js', array( 'jquery' ), '1.0.0', true );
        wp_register_script('tmc-posts-grid', plugin_dir_url( __FILE__ ) . 'js/custom-grid.js', array( 'jquery' ), '1.0.0', true );
        wp_register_script('slick', plugin_dir_url( __FILE__ ) . 'js/slick.min.js', array( 'jquery' ), '1.8.0', true );
        wp_register_script('tmc-posts-slick', plugin_dir_url( __FILE__ ) . 'js/custom-slick.js', array( 'jquery' ), '1.0.0', true );
	}
    
    public function widget_styles() {
        wp_enqueue_style('slick', plugin_dir_url( __FILE__ ) . 'css/slick.css', false, '1.8.0');
        wp_enqueue_style('tmcposts-styles', plugin_dir_url( __FILE__ ) . 'css/style.css', true, '1.0');  
	}

	private function include_widgets_files() {
        require_once( __DIR__ . '/widgets/masonry.php' );
        require_once( __DIR__ . '/widgets/carousel.php' );
        require_once( __DIR__ . '/widgets/list.php' );
	}

	public function register_widgets() {
		$this->include_widgets_files();

        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\tmc_PostMasonry() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\tmc_PostCarousel() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\tmc_PostList() );
	}

	public function __construct() {
        add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ] );
        add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
	}
}

tmcpostsLoadElementor::instance();
?>