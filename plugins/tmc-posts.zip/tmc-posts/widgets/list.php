<?php
namespace Elementortmcposts\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit;

class tmc_PostList extends Widget_Base {

	public function get_name() {
		return 'tmc-postlist';
	}

	public function get_title() {
		return esc_html__( 'TMC Posts List', 'tmc-posts' );
	}

	public function get_icon() {
		return 'eicon-post-list';
	}

	public function get_categories() {
		return [ 'tmc-widgets' ];
	}
    
    public function get_widget_taxonomies() {
        $output_terms = array();
        $args = array (
            'taxonomy' => array('category'),
            'hide_empty' => 1
        );
        $terms = get_terms($args);
        foreach($terms as $term) {
            $output_terms[$term->term_id] = $term->name;
        }
        return $output_terms;
    }
    
    public function get_widget_authors() {
        $output_authors = array();
        $output_authors['false'] = esc_html__( 'All Authors', 'tmc-posts' );
        $args = array (
            'orderby' => 'display_name',
            'order' => 'ASC',
            'role__in' => array('Administrator', 'Author', 'Editor')
        );
        $authors = get_users($args);
        foreach($authors as $author) {
            $output_authors[$author->ID] = $author->display_name;
        }
        return $output_authors;
    }
    
    public function get_widget_post_types() {
        $output_post_types = array();
        $args = array('public' => true); 
        $output = 'names';
        $operator = 'and';
        $selected_post_types = get_post_types($args,$output,$operator);
        foreach($selected_post_types as $type) {
            $output_post_types[$type] = $type;
        }
        return $output_post_types;
    }

	protected function register_controls() {
        
        $this->start_controls_section(
			'section_posts',
			[
				'label' => esc_html__( 'Posts', 'tmc-posts' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        
        $this->add_control(
			'post_type',
			[
				'label' => esc_html__( 'Post Type', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'post',
				'options' => $this->get_widget_post_types(),
			]
		);
        
        $this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
                    'DESC'  => esc_html__( 'Descending', 'tmc-posts' ),
					'ASC'  => esc_html__( 'Ascending', 'tmc-posts' )
				],
			]
		);
        
        $this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order By', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'post_date',
				'options' => [
                    'post_date'  => esc_html__( 'Date', 'tmc-posts' ),
					'title'  => esc_html__( 'Title', 'tmc-posts' ),
					'rand'  => esc_html__( 'Random', 'tmc-posts' ),
                    'comment_count'  => esc_html__( 'Comment Count', 'tmc-posts' )
				],
			]
		);
        
        $this->add_control(
			'taxonomy',
			[
				'label' => esc_html__( 'Category', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
                'multiple' => true,
				'default' => '',
				'options' => $this->get_widget_taxonomies(),
			]
		);
        
        $this->add_control(
			'author',
			[
				'label' => esc_html__( 'Author', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
                'multiple' => true,
				'default' => 'false',
				'options' => $this->get_widget_authors(),
			]
		);
        
        $this->add_control(
			'max',
			[
				'label' => esc_html__( 'Maximum number of posts', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 99,
				'step' => 1,
				'default' => 6,
			]
		);
        
        $this->add_control(
			'include', [
				'label' => esc_html__( 'Include posts by ID', 'tmc-posts' ),
                'description' => esc_html__( 'To include multiple posts, add comma between IDs.', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => ''
			]
		);
        
        $this->add_control(
			'exclude', [
				'label' => esc_html__( 'Exclude posts by ID', 'tmc-posts' ),
                'description' => esc_html__( 'To exclude multiple posts, add comma between IDs.', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => ''
			]
		);
        
        $this->add_control(
			'section_posts_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_control(
			'display_thumbnail', [
				'label' => esc_html__( 'Display post thumbnail', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmc-posts' ),
				'label_off' => esc_html__( 'No', 'tmc-posts' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'show_label' => true,
			]
		);
        
        $this->add_control(
			'display_date', [
				'label' => esc_html__( 'Display date', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmc-posts' ),
				'label_off' => esc_html__( 'No', 'tmc-posts' ),
				'return_value' => 'yes',
				'default' => '',
				'show_label' => true,
			]
		);
        
        $this->add_control(
			'display_author_name', [
				'label' => esc_html__( 'Display author name', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmc-posts' ),
				'label_off' => esc_html__( 'No', 'tmc-posts' ),
				'return_value' => 'yes',
				'default' => '',
				'show_label' => true,
			]
		);
        
        $this->add_control(
			'display_author_avatar', [
				'label' => esc_html__( 'Display author avatar', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmc-posts' ),
				'label_off' => esc_html__( 'No', 'tmc-posts' ),
				'return_value' => 'yes',
				'default' => '',
				'show_label' => true,
			]
		);
        
        $this->add_control(
			'display_author_url', [
				'label' => esc_html__( 'Enable author url', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmc-posts' ),
				'label_off' => esc_html__( 'No', 'tmc-posts' ),
				'return_value' => 'yes',
				'default' => '',
				'show_label' => true,
			]
		);
        
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_list_item',
			[
				'label' => esc_html__( 'List Item', 'tmc-posts' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'list_item_valign',
			[
				'label' => esc_html__( 'Vertical Alignment', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'align-items-start' => [
						'title' => esc_html__( 'Top', 'tmc-posts' ),
						'icon' => 'fa fa-arrow-up',
					],
					'align-items-center' => [
						'title' => esc_html__( 'Center', 'tmc-posts' ),
						'icon' => 'fa fa-minus',
					],
					'align-items-end' => [
						'title' => esc_html__( 'Bottom', 'tmc-posts' ),
						'icon' => 'fa fa-arrow-down',
					],
				],
				'default' => 'align-items-center',
				'toggle' => false,
			]
		);
        
        $this->add_control(
			'list_item_text_align',
			[
				'label' => esc_html__( 'Text Alignment', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'tmc-posts' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'tmc-posts' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'tmc-posts' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => false,
			]
		);
        
        $this->add_control(
			'column_reverse', [
				'label' => esc_html__( 'Reverse Columns', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmc-posts' ),
				'label_off' => esc_html__( 'No', 'tmc-posts' ),
				'return_value' => 'reverse',
				'default' => '',
				'show_label' => true,
			]
		);
        
        $this->add_responsive_control(
			'list_item_padding',
			[
				'label' => esc_html__( 'Padding', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_responsive_control(
			'list_item_margin',
			[
				'label' => esc_html__( 'Margin', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_control(
			'list_item_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'tmc-posts' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-wrapper' => 'background-color: {{VALUE}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_item_border',
				'label' => esc_html__( 'Border', 'tmc-posts' ),
				'selector' => '{{WRAPPER}} .tmc-posts-list-wrapper',
			]
		);
        
        $this->add_responsive_control(
			'list_item_radius',
			[
				'label' => esc_html__( 'Border Radius', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-wrapper' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'list_item_shadow',
				'label' => esc_html__( 'Box Shadow', 'tmc-posts' ),
				'selector' => '{{WRAPPER}} .tmc-posts-list-wrapper',
			]
		);
        
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_list_img',
			[
				'label' => esc_html__( 'Thumbnail', 'tmc-posts' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_responsive_control(
			'list_img_width',
			[
				'label' => esc_html__( 'Width (px)', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 500,
				'step' => 1,
				'default' => 40,
                'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-left' => 'width: {{VALUE}}px;',
                    '{{WRAPPER}} .tmc-posts-list-right' => 'width: calc(100% - {{VALUE}}px)',
				],
			]
		);
        
        $this->add_control(
			'list_img_animation',
			[
				'label' => esc_html__( 'Hover Animation', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::HOVER_ANIMATION
			]
		);
        
        $this->add_control(
			'list_thumbnail_opacity',
			[
				'label' => esc_html__( 'Opacity', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 1,
				'step' => 0.1,
				'default' => 1,
                'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-img img' => 'opacity: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'list_thumbnail_hover_opacity',
			[
				'label' => esc_html__( 'Hover Opacity', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 1,
				'step' => 0.1,
				'default' => 1,
                'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-img:hover img' => 'opacity: {{VALUE}};'
				],
			]
		);
        
        $this->add_responsive_control(
			'list_img_padding',
			[
				'label' => esc_html__( 'Padding', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_responsive_control(
			'list_img_margin',
			[
				'label' => esc_html__( 'Margin', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_control(
			'list_img_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'tmc-posts' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-img' => 'background-color: {{VALUE}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_img_border',
				'label' => esc_html__( 'Border', 'tmc-posts' ),
				'selector' => '{{WRAPPER}} .tmc-posts-list-img img',
			]
		);
        
        $this->add_responsive_control(
			'list_img_radius',
			[
				'label' => esc_html__( 'Border Radius', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-img img' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'list_img_shadow',
				'label' => esc_html__( 'Box Shadow', 'tmc-posts' ),
				'selector' => '{{WRAPPER}} .tmc-posts-list-img img',
			]
		);
        
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_list_title',
			[
				'label' => esc_html__( 'Title', 'tmc-posts' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'list_title_color',
			[
				'label' => esc_html__( 'Color', 'tmc-posts' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-title' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'list_title_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'tmc-posts' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-title:hover' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'list_title_typography',
				'label' => esc_html__( 'Typography', 'tmc-posts' ),
				'selector' => '{{WRAPPER}} .tmc-posts-list-title',
			]
		);
        
        $this->add_responsive_control(
			'list_title_padding',
			[
				'label' => esc_html__( 'Padding', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_responsive_control(
			'list_title_margin',
			[
				'label' => esc_html__( 'Margin', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_list_author',
			[
				'label' => esc_html__( 'Author', 'tmc-posts' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_responsive_control(
			'avatar_size',
			[
				'label' => esc_html__( 'Avatar Size (px)', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 5,
				'max' => 150,
				'step' => 1,
				'default' => 16,
                'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-date img' => 'width: {{VALUE}}px;height: {{VALUE}}px;'
				],
			]
		);
        
        $this->add_responsive_control(
			'avatar_radius',
			[
				'label' => esc_html__( 'Avatar Border Radius', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-date img' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_control(
			'section_author_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_control(
			'list_author_color',
			[
				'label' => esc_html__( 'Color', 'tmc-posts' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-author-link' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'list_author_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'tmc-posts' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-author-link:hover' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'list_author_typography',
				'label' => esc_html__( 'Typography', 'tmc-posts' ),
				'selector' => '{{WRAPPER}} .tmc-posts-list-author-link',
			]
		);
        
        $this->add_responsive_control(
			'list_author_padding',
			[
				'label' => esc_html__( 'Padding', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-author-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_responsive_control(
			'list_author_margin',
			[
				'label' => esc_html__( 'Margin', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-author-link' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_control(
			'list_author_icon',
			[
				'label' => esc_html__( 'Icon', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::ICONS
			]
		);
        
        $this->add_responsive_control(
			'list_author_icon_padding',
			[
				'label' => esc_html__( 'Icon Padding', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-author-link i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_list_date',
			[
				'label' => esc_html__( 'Date', 'tmc-posts' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'list_date_color',
			[
				'label' => esc_html__( 'Color', 'tmc-posts' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-date-link' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'list_date_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'tmc-posts' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-date-link:hover' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'list_date_typography',
				'label' => esc_html__( 'Typography', 'tmc-posts' ),
				'selector' => '{{WRAPPER}} .tmc-posts-list-date-link',
			]
		);
        
        $this->add_responsive_control(
			'list_date_padding',
			[
				'label' => esc_html__( 'Padding', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-date-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_responsive_control(
			'list_date_margin',
			[
				'label' => esc_html__( 'Margin', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-date-link' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_control(
			'list_date_icon',
			[
				'label' => esc_html__( 'Icon', 'tmc-posts' ),
				'type' => \Elementor\Controls_Manager::ICONS
			]
		);
        
        $this->add_responsive_control(
			'list_date_icon_padding',
			[
				'label' => esc_html__( 'Icon Padding', 'tmc-posts' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .tmc-posts-list-date-link i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->end_controls_section();

	}
    
    protected function render() {
		$settings = $this->get_settings_for_display();
        
        $post_type = $settings['post_type'];
        
        $max = $settings['max'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        $terms = $settings['taxonomy'];
        
        if ($settings['author']) {
            $author = $settings['author'];
        } else {
            $author = false;
        }
        
        if ($settings['exclude']) {
            $exclude = explode( ',', $settings['exclude'] );
        } else {
            $exclude = array();
        }
        
        if ($settings['include']) {
            $include = explode( ',', $settings['include'] );
        } else {
            $include = array();
        }
        
        if ($terms) {
            $custom_query = new WP_Query( 
            array(
                'post_type' => $post_type, 
                'post_status' => 'publish',
                'author' => $author,
                'ignore_sticky_posts' => true,
                'posts_per_page' => $max,
                'order' => $order,
                'orderby' => $orderby,
                'post__not_in' => $exclude,
                'post__in' => $include,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'category',
                        'field'    => 'term_id',
                        'terms'    => $terms,
                    )
                ),
            ));
        } else {
            $custom_query = new WP_Query( 
            array(
                'post_type' => $post_type, 
                'post_status' => 'publish',
                'author' => $author,
                'ignore_sticky_posts' => true,
                'posts_per_page' => $max,
                'order' => $order,
                'orderby' => $orderby,
                'post__not_in' => $exclude,
                'post__in' => $include,
            ));
        }
        if ($custom_query->have_posts()) {
        ?>
        <?php while($custom_query->have_posts()) : $custom_query->the_post(); ?>
        <div class="tmc-posts-list-wrapper <?php echo esc_attr($settings['list_item_valign']); ?> <?php echo esc_attr($settings['column_reverse']); ?>" style="text-align:<?php echo esc_attr($settings['list_item_text_align']); ?>;">
            <?php if ((has_post_thumbnail()) && ($settings['display_thumbnail'])) { ?>
            <?php
            $tmcposts_thumb_id = get_post_thumbnail_id();
            $tmcposts_thumb_url_array = wp_get_attachment_image_src($tmcposts_thumb_id, 'thumbnail', true);
            $tmcposts_thumb_url = $tmcposts_thumb_url_array[0];
            ?>
            <div class="tmc-posts-list-left">  
                <a class="tmc-posts-list-img elementor-animation-<?php echo esc_attr($settings['list_img_animation']); ?>" href="<?php the_permalink(); ?>">
                    <img src="<?php echo esc_url($tmcposts_thumb_url); ?>" alt="<?php the_title_attribute(); ?>" />   
                </a>    
            </div>    
            <?php } ?>
            <div class="tmc-posts-list-right">
                <a class="tmc-posts-list-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                <div class="tmc-posts-list-date">
                    <?php if ($settings['display_author_name']) { ?>           
                        <?php if ($settings['display_author_url']) { ?>
                        <a class="tmc-posts-list-author-link" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
                            <?php if ($settings['display_author_avatar']) { echo get_avatar( get_the_author_meta( 'ID' ), $settings['avatar_size'] ); } ?><?php \Elementor\Icons_Manager::render_icon( $settings['list_author_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php the_author(); ?>
                        </a>
                        <?php } else { ?>
                        <span class="tmc-posts-list-author-link">
                            <?php \Elementor\Icons_Manager::render_icon( $settings['list_author_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php the_author(); ?>
                        </span>
                        <?php } ?>
                    <?php } ?>
                    <?php if ($settings['display_date']) { ?>
                    <a class="tmc-posts-list-date-link" href="<?php esc_url(the_permalink()); ?>">
                        <?php \Elementor\Icons_Manager::render_icon( $settings['list_date_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php the_time(get_option('date_format')); ?>
                    </a>
                    <?php } ?>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
        <div class="tmc-clear"></div>   
        <?php wp_reset_postdata(); ?>
	<?php } else { ?>
    <div class="tmc-danger"><?php esc_html_e( 'Nothing was found!', 'tmc-posts' ); ?></div>         
<?php } ?>
<?php }
}
?>