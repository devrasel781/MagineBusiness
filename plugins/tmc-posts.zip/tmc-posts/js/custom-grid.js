( function( $ ) {
	$( window ).on( 'elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/tmc-postmasonry.default', function($scope){
            $scope.find('.tmc-masonry-grid').each(function () {
                $(this).egemenerdMasonry();
            });        
        });
	} );
} )( jQuery );