( function( $ ) {
	$( window ).on( 'elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/tmc-postcarousel.default', function($scope){
            $scope.find('.tmc-posts-carousel').each(function () {
                var postcolumns = $(this).data('postcolumns'); 
                if (postcolumns == 'one') {
                    $(this).slick({
                        autoplay: $(this).data('autoplay'),
                        autoplaySpeed: $(this).data('duration'),
                        infinite: $(this).data('infinite'),
                        adaptiveHeight: $(this).data('adaptive'),
                        slidesToScroll: 1,
                        rtl: $(this).data('rtl'),
                        arrows: $(this).data('nav'),
                        dots: $(this).data('dots'),
                        slidesToShow: 1,
                        fade: true                                                     
                    });   
                } else if (postcolumns == 'two') {
                    $(this).slick({
                        autoplay: $(this).data('autoplay'),
                        autoplaySpeed: $(this).data('duration'),
                        infinite: $(this).data('infinite'),
                        adaptiveHeight: $(this).data('adaptive'),
                        slidesToScroll: 1,
                        rtl: $(this).data('rtl'),
                        arrows: $(this).data('nav'),
                        dots: $(this).data('dots'),
                        slidesToShow: 2,
                        responsive: [{breakpoint: 576,settings: {slidesToShow: 1}}]                                                       
                    }); 
                } else if (postcolumns == 'three') {
                    $(this).slick({
                        autoplay: $(this).data('autoplay'),
                        autoplaySpeed: $(this).data('duration'),
                        infinite: $(this).data('infinite'),
                        adaptiveHeight: $(this).data('adaptive'),
                        slidesToScroll: 1,
                        rtl: $(this).data('rtl'),
                        arrows: $(this).data('nav'),
                        dots: $(this).data('dots'),
                        slidesToShow: 3,
                        responsive: [{breakpoint: 1200,settings: {slidesToShow: 2}},{breakpoint: 768,settings: {slidesToShow: 1}}]                                                    
                    }); 
                } else if (postcolumns == 'four') {
                    $(this).slick({
                        autoplay: $(this).data('autoplay'),
                        autoplaySpeed: $(this).data('duration'),
                        infinite: $(this).data('infinite'),
                        adaptiveHeight: $(this).data('adaptive'),
                        slidesToScroll: 1,
                        rtl: $(this).data('rtl'),
                        arrows: $(this).data('nav'),
                        dots: $(this).data('dots'),
                        slidesToShow: 4,
                        responsive: [{breakpoint: 1200,settings: {slidesToShow: 3}},{breakpoint: 992,settings: {slidesToShow: 2}},{breakpoint: 768,settings: {slidesToShow: 1}}]                                                     
                    }); 
                } else {
                    $(this).slick({
                        autoplay: $(this).data('autoplay'),
                        autoplaySpeed: $(this).data('duration'),
                        infinite: $(this).data('infinite'),
                        adaptiveHeight: $(this).data('adaptive'),
                        slidesToScroll: 1,
                        rtl: $(this).data('rtl'),
                        arrows: $(this).data('nav'),
                        dots: $(this).data('dots'),
                        slidesToShow: 5,
                        responsive: [{breakpoint: 1440,settings: {slidesToShow: 4}},{breakpoint: 1200,settings: {slidesToShow: 3}},{breakpoint: 992,settings: {slidesToShow: 2}},{breakpoint: 768,settings: {slidesToShow: 1}}]                                                 
                    }); 
                }
                });
                setTimeout(function(){
                    $scope.find('.tmc-posts-carousel').css('opacity', '1');
                }, 500);
            });        
        });
} )( jQuery );