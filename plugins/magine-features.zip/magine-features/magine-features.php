<?php
/**
* Plugin Name: Magine Features
* Plugin URI: https://www.thememasters.club/
* Description: Custom post types, widgets and shortcodes
* Version: 1.4
* Author: ThemeMasters
* Author URI: https://www.thememasters.club/
* License: URI: https://www.thememasters.club/terms-conditions/
*/

/* ---------------------------------------------------------
INCLUDE FILES
----------------------------------------------------------- */

function magine_features_main_function(){
    include_once('shortcodes.php');
    /* IF CMB2 PLUGIN IS LOADED */
    if ( defined( 'CMB2_LOADED' ) ) {
        include_once('adsadmin.php');
    }
}

add_action('plugins_loaded','magine_features_main_function');

/* Register Scripts and Styles */

function tessera_cpt_scripts() {
    if (is_singular()) {
        $magine_enable_sharing = get_theme_mod('magine_enable_sharing');
        $magine_enable_product_sharing = get_theme_mod('magine_enable_product_sharing');
        if (( $magine_enable_sharing ) || ( $magine_enable_product_sharing)) { 
            wp_enqueue_style('magine-share', plugin_dir_url( __FILE__ ) . 'css/rrssb.css', false, '1.0.0');
            wp_enqueue_script('magine-share', plugin_dir_url( __FILE__ ) . 'js/rrssb.min.js', array( 'jquery' ), '1.0.0', true ); 
        }
    }
}
add_action('wp_enqueue_scripts','tessera_cpt_scripts');

/* ---------------------------------------------------------
Ads Manager
----------------------------------------------------------- */

function magine_features_cmb2_function(){  
    include_once('adsmanager.php');
}

add_action('cmb2_init','magine_features_cmb2_function');

/* ---------------------------------------------------------
Social Media Sharing Buttons
----------------------------------------------------------- */

function magine_social_media_buttons() {
    include('social-media.php');
}

/*---------------------------------------------------
Tinymce custom button
----------------------------------------------------*/

if ( is_admin() ) {
add_action('init', 'magine_shortcodes_add_button');  
function magine_shortcodes_add_button() {  
   if ( current_user_can('edit_posts') &&  current_user_can('edit_pages') )  
   {  
     add_filter('mce_external_plugins', 'magine_add_plugin', 10);  
     add_filter('mce_buttons', 'magine_register_button', 10);  
   }  
} 

function magine_register_button($buttons) {
    array_push($buttons, "magine_mce_button");
    return $buttons;  
}  

function magine_add_plugin($plugin_array) {
    $plugin_array['magine_mce_button'] = plugin_dir_url( __FILE__ ) . 'js/shortcodes.js';
    return $plugin_array;  
}    
}

/* ---------------------------------------------------------
ELEMENTOR
----------------------------------------------------------- */

include_once('elementor.php');

/* Create a new category */

function magine_add_elementor_widget_categories( $elements_manager ) {

	$elements_manager->add_category(
		'magine-widgets',
		[
			'title' => esc_html__( 'Magine', 'magine' ),
			'icon' => 'fa fa-plug',
		]
	);

}
add_action( 'elementor/elements/categories_registered', 'magine_add_elementor_widget_categories' );

/* ---------------------------------------------------------
ADD FEATURED IMAGES TO ADMIN COLUMNS
----------------------------------------------------------- */

add_filter('manage_posts_columns', 'posts_columns', 5);
add_action('manage_posts_custom_column', 'posts_custom_columns', 5, 2);
 
function posts_columns($defaults){
    $defaults['magine_post_thumbs'] = esc_html__('Thumbs', 'magine');
    return $defaults;
}
 
function posts_custom_columns($column_name, $id){
    if($column_name === 'magine_post_thumbs'){
        echo the_post_thumbnail( 'thumbnail' );
    }
}

/* ---------------------------------------------------------
DEMO IMPORT
----------------------------------------------------------- */

function magine_import_files() {
    return array(
        array(
            'import_file_name'           => 'Demo Import',
            'import_file_url'            => 'https://www.thememasters.club/demos/magine/demo.xml',
            'import_widget_file_url'     => 'https://www.thememasters.club/demos/magine/widgets.wie',
            'import_customizer_file_url' => 'https://www.thememasters.club/demos/magine/customizer.dat'
        )
    );
}
add_filter( 'pt-ocdi/import_files', 'magine_import_files' );


function magine_after_import_setup() {
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

    set_theme_mod( 'nav_menu_locations', array(
            'magine-main-menu' => $main_menu->term_id,
        )
    );
    $front_page_id = get_page_by_title( 'Homepage' );
    $blog_page_id  = get_page_by_title( 'Blog' );
    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    update_option( 'page_for_posts', $blog_page_id->ID );

}
add_action( 'pt-ocdi/after_import', 'magine_after_import_setup' );
?>