<?php
namespace Elementormagine\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class magine_Button extends Widget_Base {

	public function get_name() {
		return 'magine-button';
	}

	public function get_title() {
		return esc_html__( 'MG Button', 'magine' );
	}

	public function get_icon() {
		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'magine-widgets' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Settings', 'magine' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        
        $this->add_control(
			'text', [
				'label' => esc_html__( 'Text', 'magine' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'VIEW MORE', 'magine' )
			]
		);
        
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'magine' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'primary',
				'options' => [
					'primary'  => esc_html__( 'Primary', 'magine' ),
                    'dark'  => esc_html__( 'Dark', 'magine' ),
					'light'  => esc_html__( 'Light', 'magine' ),
                    'success'  => esc_html__( 'Success', 'magine' ),
                    'info'  => esc_html__( 'Info', 'magine' ),
                    'warning'  => esc_html__( 'Warning', 'magine' ),
                    'danger'  => esc_html__( 'Danger', 'magine' )
				],
			]
		);
        
        $this->add_control(
			'size',
			[
				'label' => esc_html__( 'Size', 'magine' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'btn-md',
				'options' => [
					'btn-md'  => esc_html__( 'Normal', 'magine' ),
					'btn-lg'  => esc_html__( 'Large', 'magine' ),
                    'btn-sm'  => esc_html__( 'Small', 'magine' )
				],
			]
		);
        
        $this->add_control(
			'width',
			[
				'label' => esc_html__( 'Width', 'magine' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'auto',
				'options' => [
					'auto'  => esc_html__( 'Auto', 'magine' ),
					'100%'  => esc_html__( 'Fullwidth', 'magine' )
				],
			]
		);
        
        $this->add_control(
			'website_link',
			[
				'label' => esc_html__( 'Link to', 'magine' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'magine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
        
        $this->add_responsive_control(
			'text_align',
			[
				'label' => esc_html__( 'Alignment', 'magine' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'magine' ),
						'icon' => 'fas fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'magine' ),
						'icon' => 'fas fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'magine' ),
						'icon' => 'fas fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .magine-btn-wrapper' => 'text-align: {{VALUE}};'
				],
				'toggle' => true,
			]
		);
        
       
		$this->end_controls_section();
	}
    
    protected function render() {
		$settings = $this->get_settings_for_display();
		$target = $settings['website_link']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['website_link']['nofollow'] ? ' rel="nofollow"' : '';

        
        echo '<div class="magine-btn-wrapper"><a style="width:' . $settings['width'] . ';" class="btn ' . $settings['size'] . ' btn-'. $settings['style'] . '" href="' . $settings['website_link']['url'] . '"' . $target . $nofollow . '>' . $settings['text'] . '</a></div>';
	}

	protected function _content_template() {
		?>
        <div class="magine-btn-wrapper"><a style="width:{{ settings.width }};" class="btn {{ settings.size }} btn-{{ settings.style }}" href="#">{{ settings.text }}</a></div>
		<?php
	}
}
?>