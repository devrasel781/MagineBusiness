<?php
namespace Elementormagine\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit;

class magine_Cats extends Widget_Base {

	public function get_name() {
		return 'magine-list';
	}

	public function get_title() {
		return esc_html__( 'MG Categories', 'magine' );
	}

	public function get_icon() {
		return 'eicon-editor-list-ul';
	}

	public function get_categories() {
		return [ 'magine-widgets' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Settings', 'magine' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        
        $this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'magine' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => [
                    'DESC'  => esc_html__( 'Descending', 'magine' ),
					'ASC'  => esc_html__( 'Ascending', 'magine' )
				],
			]
		);
        
        $this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order By', 'magine' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'name',
				'options' => [
                    'name'  => esc_html__( 'Name', 'magine' ),
					'count'  => esc_html__( 'Post Count', 'magine' ),
                    'id'  => esc_html__( 'ID', 'magine' )
				],
			]
		);
        
        $this->add_control(
			'max',
			[
				'label' => esc_html__( 'Maximum number of categories', 'magine' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 99,
				'step' => 1,
				'default' => 6,
			]
		);
        
        $this->add_control(
			'display_bg_img', [
				'label' => esc_html__( 'Display background images', 'magine' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'magine' ),
				'label_off' => esc_html__( 'No', 'magine' ),
				'return_value' => 'yes',
				'default' => '',
				'show_label' => true,
			]
		);
        
        $this->add_control(
			'display_counts', [
				'label' => esc_html__( 'Display post counts', 'magine' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'magine' ),
				'label_off' => esc_html__( 'No', 'magine' ),
				'return_value' => 'yes',
				'default' => '',
				'show_label' => true,
			]
		);

		$this->end_controls_section();
        
        $this->start_controls_section(
			'title_section',
			[
				'label' => esc_html__( 'Widget Title', 'magine' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        
        $this->add_control(
			'heading', [
				'label' => esc_html__( 'Heading', 'magine' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => ''
			]
		);
        
        $this->add_control(
			'heading_level',
			[
				'label' => esc_html__( 'Heading Level', 'magine' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'h3',
				'options' => [
                    'h1'  => esc_html__( 'Heading 1', 'magine' ),
                    'h2'  => esc_html__( 'Heading 2', 'magine' ),
                    'h3'  => esc_html__( 'Heading 3', 'magine' ),
                    'h4'  => esc_html__( 'Heading 4', 'magine' ),
                    'h5'  => esc_html__( 'Heading 5', 'magine' ),
                    'h6'  => esc_html__( 'Heading 6', 'magine' )
				],
			]
		);
        
        $this->add_control(
			'title_border', [
				'label' => esc_html__( 'Add Border', 'magine' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'magine' ),
				'label_off' => esc_html__( 'No', 'magine' ),
				'return_value' => 'title-with-border',
				'default' => '',
				'show_label' => true,
			]
		);
        
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_list_style',
			[
				'label' => esc_html__( 'List', 'magine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_responsive_control(
			'list_item_padding',
			[
				'label' => esc_html__( 'Padding', 'magine' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_responsive_control(
			'list_item_margin',
			[
				'label' => esc_html__( 'Margin', 'magine' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_control(
			'list_item_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgba(255,255,255,0.7)',
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a' => 'background-color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'list_item_bg_hover_color',
			[
				'label' => esc_html__( 'Background Hover Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgba(255,255,255,0.9)',
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a:hover' => 'background-color: {{VALUE}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_item_border',
				'label' => esc_html__( 'Border', 'magine' ),
				'selector' => '{{WRAPPER}} .magine-cat-widget li',
			]
		);
        
        $this->add_responsive_control(
			'list_item_radius',
			[
				'label' => esc_html__( 'Border Radius', 'magine' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .magine-cat-widget li a' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_style_title',
			[
				'label' => esc_html__( 'Title', 'magine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'list_item_color',
			[
				'label' => esc_html__( 'Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#202c39',
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a .magine-cat-span1' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'list_item_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#202c39',
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a:hover .magine-cat-span1' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'list_item_typography',
				'label' => esc_html__( 'Typography', 'magine' ),
				'selector' => '{{WRAPPER}} .magine-cat-widget li a .magine-cat-span1',
			]
		);
        
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_style_count',
			[
				'label' => esc_html__( 'Post Counts', 'magine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'list_count_color',
			[
				'label' => esc_html__( 'Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a .badge.magine-cat-span2' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'list_count_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a:hover .badge.magine-cat-span2' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'list_count_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#0073aa',
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a .badge.magine-cat-span2' => 'background-color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'list_count_bg_hover_color',
			[
				'label' => esc_html__( 'Background Hover Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#0073aa',
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a:hover .badge.magine-cat-span2' => 'background-color: {{VALUE}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'list_count_typography',
				'label' => esc_html__( 'Typography', 'magine' ),
				'selector' => '{{WRAPPER}} .magine-cat-widget li a .badge.magine-cat-span2',
			]
		);
        
        $this->add_responsive_control(
			'list_count_padding',
			[
				'label' => esc_html__( 'Padding', 'magine' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a .badge.magine-cat-span2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_responsive_control(
			'list_count_radius',
			[
				'label' => esc_html__( 'Border Radius', 'magine' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .magine-cat-widget li a .badge.magine-cat-span2' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->end_controls_section();

	}
    
    protected function render() {
		$settings = $this->get_settings_for_display();
        $max = $settings['max'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        
        $args = array (
            'taxonomy' => array('category'),
            'order' => $order,
            'orderby' => $orderby,
            'hide_empty' => 1
        );
        $terms = get_terms($args);
        $i = 0;
        if ($terms) {
            echo '<ul class="magine-cat-widget">';
            foreach($terms as $term) {
                $bg_img = '';
                if ($settings['display_bg_img']) {
                    $bg_img = wp_get_attachment_image_url( get_term_meta( $term->term_id, 'magine_cmb2_cat_cover_image_id', 1 ), 'large' );
                }
                if ($i < $max) {
                    if ($settings['display_counts']) {
                        echo '<li style="background-image:url(' . esc_url($bg_img) . ')"><a href="' . esc_url( get_term_link( $term ) ) . '"><span class="magine-cat-span1">' . esc_html($term->name) . '</span><span class="magine-cat-span2 badge">' . esc_html($term->count) . '</span></a></li>';
                    } else {
                        echo '<li style="background-image:url(' . esc_url($bg_img) . ')"><a href="' . esc_url( get_term_link( $term ) ) . '"><span class="magine-cat-span1">' . esc_html($term->name) . '</span></a></li>';
                    }
                    $i++;
                } else {
                    return;
                }
            }
            echo '</ul>';
        }
    }
}
?>