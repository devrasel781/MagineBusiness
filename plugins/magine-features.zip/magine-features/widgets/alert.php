<?php
namespace Elementormagine\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class magine_Alert extends Widget_Base {

	public function get_name() {
		return 'magine-alert';
	}

	public function get_title() {
		return esc_html__( 'MG Alert', 'magine' );
	}

	public function get_icon() {
		return 'eicon-alert';
	}

	public function get_categories() {
		return [ 'magine-widgets' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Settings', 'magine' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        
        $this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'magine' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
                'rows' => 10,
				'default' => esc_html__( 'Well done! You successfully read this important alert message.', 'magine' )
			]
		);
        
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'magine' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'primary',
				'options' => [
					'primary'  => esc_html__( 'Primary', 'magine' ),
                    'success'  => esc_html__( 'Success', 'magine' ),
                    'info'  => esc_html__( 'Info', 'magine' ),
                    'warning'  => esc_html__( 'Warning', 'magine' ),
                    'danger'  => esc_html__( 'Danger', 'magine' )
				],
			]
		);
        
        $this->add_control(
			'dismiss', [
				'label' => esc_html__( 'Dismissible', 'magine' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'magine' ),
				'label_off' => esc_html__( 'No', 'magine' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'show_label' => true,
			]
		);
       
		$this->end_controls_section();
	}
    
    protected function render() {
		$settings = $this->get_settings_for_display();
        
        if ($settings['dismiss']) {
            echo '<div class="alert alert-dismissible alert-' . $settings['style'] . '"><div class="close" data-dismiss="alert">&times;</div>' . $settings['text'] . '</div>';
        } else {
            echo '<div class="alert alert-' . $settings['style'] . '">' . $settings['text'] . '</div>';
        }
	}

	protected function _content_template() {
		?>
		<# if ( settings.dismiss ) { #>
        <div class="alert alert-{{{ settings.style }}}"><div class="close" data-dismiss="alert">&times;</div>{{{ settings.text }}}</div>              
		<# } else { #>
        <div class="alert alert-{{{ settings.style }}}">{{{ settings.text }}}</div>     
        <# } #>    
		<?php
	}
}
?>