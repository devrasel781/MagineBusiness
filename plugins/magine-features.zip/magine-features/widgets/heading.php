<?php
namespace Elementormagine\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit;

class magine_Heading extends Widget_Base {

	public function get_name() {
		return 'magine-heading';
	}

	public function get_title() {
		return esc_html__( 'MG Heading', 'magine' );
	}

	public function get_icon() {
		return 'eicon-heading';
	}

	public function get_categories() {
		return [ 'magine-widgets' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Settings', 'magine' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        
        $this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'magine' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Title', 'magine' )
			]
		);
        
        $this->add_control(
			'html_tag',
			[
				'label' => esc_html__( 'HTML Tag', 'magine' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'h3',
				'options' => [
                    'h1'  => esc_html__( 'H1', 'magine' ),
					'h2'  => esc_html__( 'H2', 'magine' ),
                    'h3'  => esc_html__( 'H3', 'magine' ),
                    'h4'  => esc_html__( 'H4', 'magine' ),
                    'h5'  => esc_html__( 'H5', 'magine' ),
                    'h6'  => esc_html__( 'H6', 'magine' ),
                    'div'  => esc_html__( 'div', 'magine' ),
                    'span'  => esc_html__( 'span', 'magine' ),
                    'p'  => esc_html__( 'p', 'magine' ),
				],
			]
		);
        
        $this->add_control(
			'button_txt', [
				'label' => esc_html__( 'Link Text', 'magine' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'View More', 'magine' )
			]
		);
        
        $this->add_control(
			'website_link',
			[
				'label' => esc_html__( 'Destination URL', 'magine' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'magine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
        
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_styles',
			[
				'label' => esc_html__( 'Styles', 'magine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);  
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pagination_item_typography',
				'label' => esc_html__( 'Title Typography', 'magine' ),
				'selector' => '{{WRAPPER}} .title-with-border, {{WRAPPER}} .title-with-border span, {{WRAPPER}} .title-with-border p',
			]
		);
        
        $this->add_control(
			'color',
			[
				'label' => esc_html__( 'Title Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#202c39',
				'selectors' => [
					'{{WRAPPER}} .title-with-border' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'bg_color',
			[
				'label' => esc_html__( 'Title Background Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .title-with-border span' => 'background: {{VALUE}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'link_typography',
				'label' => esc_html__( 'Link Typography', 'magine' ),
				'selector' => '{{WRAPPER}} .title-with-border a',
			]
		);
        
        $this->add_control(
			'link_color',
			[
				'label' => esc_html__( 'Link Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#0073aa',
				'selectors' => [
                    '{{WRAPPER}} .title-with-border a' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'hover_color',
			[
				'label' => esc_html__( 'Link Hover Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#005177',
				'selectors' => [
                    '{{WRAPPER}} .title-with-border a:hover' => 'color: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'link_bg_color',
			[
				'label' => esc_html__( 'Link Background Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .title-with-border a' => 'background: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'border_color',
			[
				'label' => esc_html__( 'Border Color', 'magine' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgba(0,0,0,0.1)',
				'selectors' => [
					'{{WRAPPER}} .title-with-border span:before' => 'background: {{VALUE}};'
				],
			]
		);
        
        $this->add_control(
			'border_height',
			[
				'label' => esc_html__( 'Border Height (px)', 'magine' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 50,
				'step' => 1,
				'default' => 3,
                'selectors' => [
					'{{WRAPPER}} .title-with-border span:before' => 'height: {{VALUE}}px;',
				],
			]
		);
        
        $this->add_responsive_control(
			'margin',
			[
				'label' => esc_html__( 'Margin', 'magine' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .title-with-border' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
       
		$this->end_controls_section();
	}
    
    protected function render() {
		$settings = $this->get_settings_for_display();
		$target = $settings['website_link']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['website_link']['nofollow'] ? ' rel="nofollow"' : '';

        if ($settings['website_link']['url']) {
            echo '<' . $settings['html_tag'] . ' class="title-with-border"><span>' . $settings['title'] . '</span><a href="' . $settings['website_link']['url'] . '"' . $target . $nofollow . '>' . $settings['button_txt'] . '</a></' . $settings['html_tag'] . '>';
        } else {
            echo '<' . $settings['html_tag'] . ' class="title-with-border"><span>' . $settings['title'] . '</span></' . $settings['html_tag'] . '>';
        }
	}
}
?>