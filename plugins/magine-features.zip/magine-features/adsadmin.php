<?php
class magineads_Admin {
	private $key = 'magine_ads';
	private $metabox_id = 'magineads_option_metabox';
	protected $title = '';
	protected $options_page = '';
	public function __construct() {
		$this->title = esc_html__( 'Ads Manager', 'magine' );
        $this->menutitle = esc_html__( 'Ads Manager', 'magine' );
	}

	public function hooks() {
		add_action( 'admin_init', array( $this, 'init' ) );
		add_action( 'admin_menu', array( $this, 'magine_add_ads_page' ) );
		add_action( 'cmb2_init', array( $this, 'magine_add_ads_page_metabox' ) );
	}

	public function init() {
		register_setting( $this->key, $this->key );
	}

	public function magine_add_ads_page() {
		$this->options_page = add_menu_page( $this->title, $this->menutitle, 'manage_options', $this->key, array( $this, 'magine_admin_ads_display' ), 'dashicons-editor-table' );
		add_action( "admin_print_styles-{$this->options_page}", array( 'CMB2_hookup', 'enqueue_cmb_css' ) );
	}

	public function magine_admin_ads_display() {
		?>
    <div class="wrap cmb2-options-page <?php echo esc_html($this->key); ?>" style="margin-top:20px;max-width:800px;">
        <style>.cmb2-options-page .button-primary {margin-top:20px;float:right;}.cmb2-options-page .cmb2-text-url {width:100% !important;}</style>
        <?php cmb2_metabox_form( $this->metabox_id, $this->key ); ?>
        <div style="clear:both;"></div>
    </div>
    <?php
	}

	function magine_add_ads_page_metabox() {
        $prefix = 'magine_ads_';

		$cmb = new_cmb2_box( array(
			'id'         => $this->metabox_id,
			'hookup'     => false,
			'cmb_styles' => true,
			'show_on'    => array(
				// These are important, don't remove
				'key'   => 'options-page',
				'value' => array( $this->key, )
			),
		) );
        
        $cmb->add_field( array(
            'name' => '',
            'desc' => esc_html__( 'Enable Ads Manager', 'magine' ),
            'id'   => $prefix . 'enable',
            'type' => 'checkbox',
        ) );
        
        $cmb->add_field(
            array(
            'id' => $prefix . 'imageads',
            'type' => 'group',
            'options' => array(
                'group_title'   => esc_html__( 'Image {#}', 'magine' ),
                'add_button' => esc_html__( 'Add Another Image', 'magine' ),
                'remove_button' => esc_html__( 'Remove Image', 'magine' ),
                'sortable' => true,
                'closed'     => true,
            ),
            'fields' => array(
                array(
                    'name' => esc_html__( 'Select Field:', 'magine'),
                    'id' => $prefix . 'field',
                    'desc' => esc_html__( 'Select a field to display this ad.', 'magine'),
                    'type' => 'select',
                    'options' => array(
                        'none' => esc_html__( 'None', 'magine' ),
                        'magine_before_posts' => esc_html__( 'Before Posts', 'magine' ),
                        'magine_after_posts' => esc_html__( 'After Posts', 'magine' ),
                        'magine_before_single_post' => esc_html__( 'Before Single Post', 'magine' ),
                        'magine_after_single_post' => esc_html__( 'After Single Post', 'magine' ),
                        'magine_before_footer' => esc_html__( 'Before Footer', 'magine' ),
                        'magine_header_banner' => esc_html__( 'Header (Layout 3)', 'magine' )
                    ),
                ),
                array(
                    'name'    => esc_html__( 'Image:', 'magine'),
                    'desc'    => esc_html__( 'Upload an image or enter an URL.', 'magine'),
                    'id'      => $prefix . 'image',
                    'type'    => 'file',
                    'text'    => array(
                        'add_upload_file_text' => esc_html__( 'Upload Image', 'magine')
                    ),
                    'query_args' => array(
                        'type' => array('image/gif','image/jpeg','image/png'),
                    ),
                    'preview_size' => 'medium',
                ),
                array(
                    'name' => esc_html__( 'Destination URL:', 'magine'),
                    'desc' => esc_html__( 'Example; https://www.thememasters.club', 'magine'),
                    'id' => $prefix . 'destination',
                    'type' => 'text_url'
                ),
            ),
        ));
        
        $cmb->add_field(
            array(
            'id' => $prefix . 'codeads',
            'type' => 'group',
            'options' => array(
                'group_title'   => esc_html__( 'Code {#}', 'magine' ),
                'add_button' => esc_html__( 'Add Another Code', 'magine' ),
                'remove_button' => esc_html__( 'Remove Code', 'magine' ),
                'sortable' => true,
                'closed'     => true,
            ),
            'fields' => array(
                array(
                    'name' => esc_html__( 'Select Field:', 'magine'),
                    'id' => $prefix . 'field',
                    'desc' => esc_html__( 'Select a field to display this ad.', 'magine'),
                    'type' => 'select',
                    'options' => array(
                        'none' => esc_html__( 'None', 'magine' ),
                        'magine_before_posts' => esc_html__( 'Before Posts', 'magine' ),
                        'magine_after_posts' => esc_html__( 'After Posts', 'magine' ),
                        'magine_before_single_post' => esc_html__( 'Before Single Post', 'magine' ),
                        'magine_after_single_post' => esc_html__( 'After Single Post', 'magine' ),
                        'magine_before_footer' => esc_html__( 'Before Footer', 'magine' ),
                        'magine_header_banner' => esc_html__( 'Header (Layout 3)', 'magine' )
                    ),
                ),
                array(
                    'name' => esc_html__( 'Code:', 'magine'),
                    'desc' => esc_html__( 'Paste your code snippet in the textbox above', 'magine'),
                    'id' => $prefix . 'code',
                    'type' => 'textarea_code'
                ),
            ),
        ));
	}

	public function __get( $field ) {
		if ( in_array( $field, array( 'key', 'metabox_id', 'title', 'options_page' ), true ) ) {
			return $this->{$field};
		}

		throw new Exception( 'Invalid property: ' . $field );
	}

}

function magineads_admin() {
	static $object = null;
	if ( is_null( $object ) ) {
		$object = new magineads_Admin();
		$object->hooks();
	}

	return $object;
}

function magineads_get_option( $key = '' ) {
	return cmb2_get_option( magineads_admin()->key, $key );
}

magineads_admin();
?>