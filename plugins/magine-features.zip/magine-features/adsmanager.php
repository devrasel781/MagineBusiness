<?php
/*---------------------------------------------------
Ads Manager
----------------------------------------------------*/

function magine_add_before_footer() {
    $magine_ads_imageads = magineads_get_option( 'magine_ads_imageads' );
    $magine_ads_codeads = magineads_get_option( 'magine_ads_codeads' );
    if (!empty($magine_ads_imageads)) {
        foreach ( (array) $magine_ads_imageads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_image = $magine_ads_destination = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_before_footer') {
                if (!is_page()) {
                if ( isset( $entry['magine_ads_image'] ) ) {            
                    $magine_ads_image = $entry['magine_ads_image'];
                }
                if ( isset( $entry['magine_ads_destination'] ) ) {            
                    $magine_ads_destination = $entry['magine_ads_destination'];
                } ?>
<div class="container">
<div class="magine-image-ad <?php echo esc_html($magine_ads_field); ?>">
    <a href="<?php echo esc_url($magine_ads_destination); ?>" target="_blank">
        <img src="<?php echo esc_url($magine_ads_image); ?>" alt="" />
    </a>
</div>
</div>    
<?php }}
        }
    }
    if (!empty($magine_ads_codeads)) {
        foreach ( (array) $magine_ads_codeads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_code = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_before_footer') {
                if (!is_page()) {
                if ( isset( $entry['magine_ads_code'] ) ) {            
                    $magine_ads_code = $entry['magine_ads_code'];
                } ?>
<div class="container">
<div class="magine-code-ad <?php echo esc_html($magine_ads_field); ?>">
    <?php echo $magine_ads_code; ?>
</div>
</div>    
<?php }}
        }
    }    
}

function magine_add_before_single_post() {
    $magine_ads_imageads = magineads_get_option( 'magine_ads_imageads' );
    $magine_ads_codeads = magineads_get_option( 'magine_ads_codeads' );
    if (!empty($magine_ads_imageads)) {
        foreach ( (array) $magine_ads_imageads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_image = $magine_ads_destination = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_before_single_post') {
                if ( isset( $entry['magine_ads_image'] ) ) {            
                    $magine_ads_image = $entry['magine_ads_image'];
                }
                if ( isset( $entry['magine_ads_destination'] ) ) {            
                    $magine_ads_destination = $entry['magine_ads_destination'];
                } ?>
<div class="magine-image-ad <?php echo esc_html($magine_ads_field); ?>">
    <a href="<?php echo esc_url($magine_ads_destination); ?>" target="_blank">
        <img src="<?php echo esc_url($magine_ads_image); ?>" alt="" />
    </a>
</div>  
<?php }
        }
    }
    if (!empty($magine_ads_codeads)) {
        foreach ( (array) $magine_ads_codeads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_code = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_before_single_post') {
                if ( isset( $entry['magine_ads_code'] ) ) {            
                    $magine_ads_code = $entry['magine_ads_code'];
                } ?>
<div class="magine-code-ad <?php echo esc_html($magine_ads_field); ?>">
    <?php echo $magine_ads_code; ?>
</div>   
<?php }
        }
    }    
}

function magine_add_after_single_post() {
    $magine_ads_imageads = magineads_get_option( 'magine_ads_imageads' );
    $magine_ads_codeads = magineads_get_option( 'magine_ads_codeads' );
    if (!empty($magine_ads_imageads)) {
        foreach ( (array) $magine_ads_imageads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_image = $magine_ads_destination = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_after_single_post') {
                if ( isset( $entry['magine_ads_image'] ) ) {            
                    $magine_ads_image = $entry['magine_ads_image'];
                }
                if ( isset( $entry['magine_ads_destination'] ) ) {            
                    $magine_ads_destination = $entry['magine_ads_destination'];
                } ?>
<div class="magine-image-ad <?php echo esc_html($magine_ads_field); ?>">
    <a href="<?php echo esc_url($magine_ads_destination); ?>" target="_blank">
        <img src="<?php echo esc_url($magine_ads_image); ?>" alt="" />
    </a>
</div>  
<?php }
        }
    }
    if (!empty($magine_ads_codeads)) {
        foreach ( (array) $magine_ads_codeads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_code = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_after_single_post') {
                if ( isset( $entry['magine_ads_code'] ) ) {            
                    $magine_ads_code = $entry['magine_ads_code'];
                } ?>
<div class="magine-code-ad <?php echo esc_html($magine_ads_field); ?>">
    <?php echo $magine_ads_code; ?>
</div>  
<?php }
        }
    }     
}

function magine_add_before_posts() {
    $magine_ads_imageads = magineads_get_option( 'magine_ads_imageads' );
    $magine_ads_codeads = magineads_get_option( 'magine_ads_codeads' );
    if (!empty($magine_ads_imageads)) {
        foreach ( (array) $magine_ads_imageads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_image = $magine_ads_destination = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_before_posts') {
                if ( isset( $entry['magine_ads_image'] ) ) {            
                    $magine_ads_image = $entry['magine_ads_image'];
                }
                if ( isset( $entry['magine_ads_destination'] ) ) {            
                    $magine_ads_destination = $entry['magine_ads_destination'];
                } ?>
<div class="magine-image-ad <?php echo esc_html($magine_ads_field); ?>">
    <a href="<?php echo esc_url($magine_ads_destination); ?>" target="_blank">
        <img src="<?php echo esc_url($magine_ads_image); ?>" alt="" />
    </a>
</div>  
<?php }
        }
    }
    if (!empty($magine_ads_codeads)) {
        foreach ( (array) $magine_ads_codeads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_code = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_before_posts') {
                if ( isset( $entry['magine_ads_code'] ) ) {            
                    $magine_ads_code = $entry['magine_ads_code'];
                } ?>
<div class="magine-code-ad <?php echo esc_html($magine_ads_field); ?>">
    <?php echo $magine_ads_code; ?>
</div>  
<?php }
        }
    }     
}

function magine_add_after_posts() {
    $magine_ads_imageads = magineads_get_option( 'magine_ads_imageads' );
    $magine_ads_codeads = magineads_get_option( 'magine_ads_codeads' );
    if (!empty($magine_ads_imageads)) {
        foreach ( (array) $magine_ads_imageads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_image = $magine_ads_destination = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_after_posts') {
                if ( isset( $entry['magine_ads_image'] ) ) {            
                    $magine_ads_image = $entry['magine_ads_image'];
                }
                if ( isset( $entry['magine_ads_destination'] ) ) {            
                    $magine_ads_destination = $entry['magine_ads_destination'];
                } ?>
<div class="magine-image-ad <?php echo esc_html($magine_ads_field); ?>">
    <a href="<?php echo esc_url($magine_ads_destination); ?>" target="_blank">
        <img src="<?php echo esc_url($magine_ads_image); ?>" alt="" />
    </a>
</div>  
<?php }
        }
    }
    if (!empty($magine_ads_codeads)) {
        foreach ( (array) $magine_ads_codeads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_code = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_after_posts') {
                if ( isset( $entry['magine_ads_code'] ) ) {            
                    $magine_ads_code = $entry['magine_ads_code'];
                } ?>
<div class="magine-code-ad <?php echo esc_html($magine_ads_field); ?>">
    <?php echo $magine_ads_code; ?>
</div>  
<?php }
        }
    }     
}

function magine_add_header_banner() {
    $magine_ads_imageads = magineads_get_option( 'magine_ads_imageads' );
    $magine_ads_codeads = magineads_get_option( 'magine_ads_codeads' );
    if (!empty($magine_ads_imageads)) {
        foreach ( (array) $magine_ads_imageads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_image = $magine_ads_destination = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_header_banner') {
                if ( isset( $entry['magine_ads_image'] ) ) {            
                    $magine_ads_image = $entry['magine_ads_image'];
                }
                if ( isset( $entry['magine_ads_destination'] ) ) {            
                    $magine_ads_destination = $entry['magine_ads_destination'];
                } ?>
<div class="magine-image-ad <?php echo esc_html($magine_ads_field); ?>">
    <a href="<?php echo esc_url($magine_ads_destination); ?>" target="_blank">
        <img src="<?php echo esc_url($magine_ads_image); ?>" alt="" />
    </a>
</div>  
<?php }
        }
    }
    if (!empty($magine_ads_codeads)) {
        foreach ( (array) $magine_ads_codeads as $key => $entry ) { 
            $magine_ads_field = $magine_ads_code = '';
            if ( isset( $entry['magine_ads_field'] ) ) {            
                $magine_ads_field = $entry['magine_ads_field'];
            }
            if ($magine_ads_field == 'magine_header_banner') {
                if ( isset( $entry['magine_ads_code'] ) ) {            
                    $magine_ads_code = $entry['magine_ads_code'];
                } ?>
<div class="magine-code-ad <?php echo esc_html($magine_ads_field); ?>">
    <?php echo $magine_ads_code; ?>
</div>  
<?php }
        }
    }     
}

$magine_ads_enable = magineads_get_option( 'magine_ads_enable' );

if ($magine_ads_enable == 'on') {
    add_action('magine_before_footer','magine_add_before_footer');
    add_action('magine_before_single_post','magine_add_before_single_post');
    add_action('magine_after_single_post','magine_add_after_single_post');
    add_action('magine_before_posts','magine_add_before_posts');
    add_action('magine_after_posts','magine_add_after_posts');
    add_action('magine_header_banner','magine_add_header_banner');
}
?>