<?php
namespace Elementormagine;

class magineLoadElementor {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
    
    /*---------------------------------------------------
    public function preview_styles() {
        wp_enqueue_style('magine-elementor-preview', plugin_dir_url( __FILE__ ) . 'css/preview.css', false, '1.0');
	}
    ----------------------------------------------------*/

	private function include_widgets_files() {
        require_once( __DIR__ . '/widgets/button.php' );
        require_once( __DIR__ . '/widgets/alert.php' );
        require_once( __DIR__ . '/widgets/cats.php' );
        require_once( __DIR__ . '/widgets/heading.php' );
	}

	public function register_widgets() {
		$this->include_widgets_files();

        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\magine_Button() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\magine_Alert() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\magine_Cats() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\magine_Heading() );
	}

	public function __construct() {
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
        /*---------------------------------------------------
        add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'preview_styles' ] );
        ----------------------------------------------------*/
	}
}

magineLoadElementor::instance();
?>