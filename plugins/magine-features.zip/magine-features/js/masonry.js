( function( $ ) {
	$( window ).on( 'elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/magine-masonry.default', function($scope){
            $scope.find('.magine-masonry-grid2').egemenerdMasonry();
        });
	} );
} )( jQuery );