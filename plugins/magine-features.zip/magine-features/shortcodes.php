<?php
add_shortcode('mpbutton', 'mpbutton');
add_shortcode('mpalert', 'mpalert');

add_filter("the_content", "magine_content_filter");
add_filter("widget_text", "do_shortcode");
add_filter("widget_text", "magine_content_filter", 9);

function magine_content_filter($content) {
 
	// array of custom shortcodes requiring the fix 
	$block = join("|",array("contact-form-7","mpbutton","mpalert"));
 
	// opening tag
	$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
		
	// closing tag
	$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
 
	return $rep;
 
}

// Alert
function mpalert($atts, $content = null) {
	extract(shortcode_atts(array(
        "style" => 'style',
        "dismissible" => 'dismissible'
	), $atts));   
    if (empty($dismissible)) {
        return '<div class="alert alert-' . esc_html($style) . '">' . wp_kses_post($content) . '</div>';
    } else {
        return '<div class="alert alert-' . esc_html($style) . '"><div class="close" data-dismiss="alert">&times;</div>' . wp_kses_post($content) . '</div>';
    }
}

// Button
function mpbutton($atts, $content = null) {
	extract(shortcode_atts(array(
		"url" => 'url',
        "newtab" => 'newtab',
        "style" => 'style',
        "size" => 'size'
	), $atts));
    if ($newtab != 'yes') {
        return '<a href="' . esc_url($url) . '" class="btn btn-' . esc_html($style) . ' ' . esc_html($size) . '">' . esc_html($content) . '</a>';
    }
    else {
        return '<a href="' . esc_url($url) . '" target="_blank" class="btn btn-' . esc_html($style) . ' ' . esc_html($size) . '">' . esc_html($content) . '</a>';
    }
}
?>